package edu.caltech.cs2.helpers;

public class NewNode {
    public static int NUM_CALLS = 0;
}
