package edu.caltech.cs2.project03;

import edu.caltech.cs2.datastructures.CircularArrayFixedSizeQueue;
import edu.caltech.cs2.interfaces.IQueue;

import java.util.Random;


public class CircularArrayFixedSizeQueueGuitarString {
    public CircularArrayFixedSizeQueueGuitarString(double frequency) {

    }

    public int length() {
        return -1;
    }

    public void pluck() {

    }

    public void tic() {

    }

    public double sample() {
        return 0;
    }
}
