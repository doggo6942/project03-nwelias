package edu.caltech.cs2.datastructures;

import edu.caltech.cs2.interfaces.IDeque;
import edu.caltech.cs2.interfaces.IQueue;
import edu.caltech.cs2.interfaces.IStack;

import java.util.Iterator;

public class ArrayDeque<E> implements IDeque<E>, IQueue<E>, IStack<E> {
    private int size = 0;
    private int back = 0;
    private E first = 0;
    private E[] elements;


    public ArrayDeque(){
        this.elements = (E[]) new Object[10];
        this.size = 0;
        //ArrayDeque<E> deque = new ArrayDeque<E>(10);

    }
    public ArrayDeque(int intialCapacity){
        this.elements = (E[]) new Object[10];
        this.size = 0;
       E[] newArray = (E[]) new Object[capacity] {
        }
        public void resize(){
               int start = first + 1;
               int end = back - 1;
               if(start > end) {
                   int sizeOfFront = elements.length - start;
                   int sizeofBack = size - sizeOfFront;
                   System.arraycopy(elements, start, newArray, 0, sizeOfFront);
                   System.arraycopy(elements, 0, newArray, sizeOfFront, sizeofBack);
               }
               else {
                   System.arraycopy(elements, start, newArray, 0, size);
               }
               first = newArray.length -1;
               back = size;
               elements = newArray;


               }
        }


    }
    public boolean isEmpty() {
        return this.size == 0;
    }


    @Override
    public void addFront(E e) {
        if (size >= elements.length) {
            E[] newElements = (E[]) new Object[elements.length*2];
            for(int i = 0; i< elements.length; i++)
                newElements[i+1] = elements[i];
        }
        else {
            for(int i = elements.length -1; i>=0; i--) {
                elements[i + 1] = elements[i];
            }
            elements[0] = e;
            size = size + 1;
        }
    }

//        Node prevFirst = first;
//        first = new Node();
//        first.e = e;
//        first.next = prevFirst;
//        first.prev = null;
//        if(last==null){
//            last = first;
//        }
//        n++
//        }
//
//        elements[head= (head - 1) & (elements.length -1)] = e;
//        //insert elelemnt to the first bit of the head, modify the head value at the same time
//        elements.length -1  = e;
//
//
//    }

    @Override
    public void addBack(E e) {
        if (size >= elements.length) {
            E[] newElements = (E[]) new Object[elements.length*2];
            for(int i = 0; i< elements.length; i++)
                newElements[i] = elements[i];
        }
        else {
//            for(int i = elements.length -1; i>=0; i--) {
//                elements[i + 1] = elements[i];
//            }
            elements[size] = e;
            size = size + 1;
        }

    }

    @Override
    public E removeFront() {
        if (size == 0) {
            return null;
        } else {
            int i = 0;
            elements[i] = first;
            for (i = elements.length - 1; i >= 0; i--) {
                elements[i - 1] = elements[i];
            }
            size = size - 1;
        }
        return first;
    }

    @Override
    public E removeBack() {
        if (size == 0) {
            return null;
        } else {
            E last = elements[elements.length - 1];
            size = size - 1;
            return last;
        }
    }

    @Override
    public boolean enqueue(E e) {
        addBack(e);
        return true;
    }

    @Override
    public E dequeue() {
        removeFront();
        return null;
    }

    @Override
    public boolean push(E e) {
        addFront(e);
        return false;
    }

    @Override
    public E pop() {
        removeFront();
        return null;
    }

    @Override
    public E peekFront() {
        return elements[0];
    }

    @Override
    public E peekBack() {
        return elements[elements.length-1];
    }

    @Override
    public E peek() {
        return peekBack();
    }

    @Override
    public Iterator<E> iterator() {
        Iterator<E> iter = new Iterator<E>() {
            private int index = 0;

            @Override
            public E next() {
                index += 1;
                return elements[index];
            }
            @Override
            public boolean hasNext() {
                if (index < size) {
                    return true;
                }
                return false;
            }
        };
        return iter;
    }


    @Override
    public int size() {
        return size;
    }
}

